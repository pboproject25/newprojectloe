/**
 * Interface untuk unit yang dapat menggunakan skill atau kemampuan spesial.
 */
public interface Castable {
    void castSkill(Character target);
}
