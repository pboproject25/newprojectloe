import greenfoot.*;  
/**
 * Write a description of class MainMenu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainMenu extends LegendOfElkaidu
{

    /**
     * Constructor for objects of class MainMenu.
     * 
     */
    public MainMenu()
    {
    }
}
