/**
 * Interface untuk unit yang dapat bergerak.
 */
public interface Movable {
    void moveForward();
    void stop();
}
