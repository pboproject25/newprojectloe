/**
 * Interface untuk unit dengan serangan jarak dekat.
 */
public interface MeleeUnit {
    void slash(Character target); // contoh aksi serangan melee
}
