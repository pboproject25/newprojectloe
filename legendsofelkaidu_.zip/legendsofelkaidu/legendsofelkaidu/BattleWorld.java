// File: BattleWorld.java (KODE ANDA SEKARANG VALID)
import greenfoot.*;

public class BattleWorld extends LegendOfElkaidu
{
    public BattleWorld()
    {    

        super(800, 400, 1); 

    }
}