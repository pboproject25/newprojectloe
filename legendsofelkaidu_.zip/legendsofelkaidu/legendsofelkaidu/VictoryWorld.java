import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class VictoryWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class VictoryWorld extends LegendOfElkaidu
{

    /**
     * Constructor for objects of class VictoryWorld.
     * 
     */
    public VictoryWorld()
    {
    }
}
