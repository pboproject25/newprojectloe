/**
 * Interface untuk unit yang dapat menyerang target.
 */
public interface Attackable {
    void attack(Character target);
}
