/**
 * Interface untuk unit yang memberikan reward ketika dikalahkan.
 */
public interface Rewardable {
    int getRewardValue();
}
