/**
 * Interface untuk unit dengan serangan jarak jauh.
 */
public interface RangedUnit {
    void shootProjectile(Character target);
}
